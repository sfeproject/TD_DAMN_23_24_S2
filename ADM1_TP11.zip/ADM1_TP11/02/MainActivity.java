package com.profiltel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
	private EditText edMarque;
    private Spinner spCouleur;
    private SeekBar seekNbVitesse;
    private CheckBox chEconomique;
    private Button btnEnregister;
	private Button btnAfficher;
	private Button btnPasser;
	private Button btnPasserParcel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique2();
    }

    private void initGraphique2() {
        edMarque=findViewById(R.id.edMarque);
        spCouleur=findViewById(R.id.spCouleur);
        seekNbVitesse=findViewById(R.id.seekNbVitesse);
        chEconomique=findViewById(R.id.chEconomique);
        btnEnregister=findViewById(R.id.btnEnregister);
        btnAfficher=findViewById(R.id.btnAfficher);
        btnPasser=findViewById(R.id.btnPasser);
        btnPasserParcel=findViewById(R.id.btnPasserParcel);

    }
}