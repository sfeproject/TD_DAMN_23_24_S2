package com.vente;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText edM;
    private EditText edP;
    private Button btnC;
    private Spinner spP;
    private SeekBar seekNbC;
    private RadioGroup rdgC;
    private RadioButton rdN;
    private CheckBox chE;
    private CheckBox chC;
    private Button btnA;
    private Button btnE;
    private Button btnQ;
    private ListView lstS;
    private ArrayAdapter<Smartphone> adpS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        edM = findViewById(R.id.edM);
        edP = findViewById(R.id.edP);
        btnC = findViewById(R.id.btnC);
        spP = findViewById(R.id.spP);
        seekNbC = findViewById(R.id.seekNbC);
        rdgC = findViewById(R.id.rdgC);
        rdN = findViewById(R.id.rdN);
        chE = findViewById(R.id.chE);
        chC = findViewById(R.id.chC);
        btnA = findViewById(R.id.btnA);
        btnE = findViewById(R.id.btnE);
        btnQ = findViewById(R.id.btnQ);
        lstS = findViewById(R.id.lstS);
        adpS = new ArrayAdapter<Smartphone>(this, android.R.layout.simple_list_item_1);
        lstS.setAdapter(adpS);
        effacer();
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
     

    }

    private void classifier() {
    
    }

    private void ajouter() {
        
    }

    private void effacer() {
       
    }

    private void quitter() {
        
    }

    private void afficher(int position) {
        
    }
}
