package com.vente;

public class Smartphone {
    private String marque;
    private int prix;
    private String processeur;  // Cortex A7-Cortex A9-Cortex A15
    private int nbCamera;
    private boolean estNoir;  // true: Noir   false:Blanc
    private boolean ecouteur;     // true: avec écouteurs false: sans écouteurs
    private boolean cage;     // true: avec cage false: sans cage

    public Smartphone(String marque, int prix, String processeur, int nbCamera, boolean estNoir, boolean ecouteur, boolean cage) {
        this.marque = marque;
        this.prix = prix;
        this.processeur = processeur;
        this.nbCamera = nbCamera;
        this.estNoir = estNoir;
        this.ecouteur = ecouteur;
        this.cage = cage;
    }

    public String getMarque() {
        return marque;
    }

    public int getPrix() {
        return prix;
    }

    public String getProcesseur() {
        return processeur;
    }

    public String strCouleur() {
        return (estNoir) ? "Noir" : "Blanc";
    }

    public String strEcouteurs() {
        return (ecouteur) ? "ECT" : "";
    }

    public String strCage() {
        return (cage) ? "CAG" : "";
    }

    @Override
    public String toString() {
        return marque + "{" +
                prix + " DT" +
                "- " + processeur +
                "- " + nbCamera + "Cam" +
                "- " + strCouleur() +
                "- " + strEcouteurs() +
                "- " + strCage() +
                '}';
    }
}
