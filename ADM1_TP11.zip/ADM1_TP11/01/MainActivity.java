package com.profiltel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
	private EditText edNom;
    private Spinner spVille;
    private SeekBar seekNbEtoiles;
    private CheckBox chTraditionnel;
    private Button btnEnregister;
	private Button btnAfficher;
	private Button btnPasser;
	private Button btnPasserParcel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGraphique1();
    }

    private void initGraphique1() {
        edNom=findViewById(R.id.edNom);
        spVille=findViewById(R.id.spVille);
        seekNbEtoiles=findViewById(R.id.seekNbEtoiles);
        chTraditionnel=findViewById(R.id.chTraditionnel);
        btnEnregister=findViewById(R.id.btnEnregister);
        btnAfficher=findViewById(R.id.btnAfficher);
        btnPasser=findViewById(R.id.btnPasser);
        btnPasserParcel=findViewById(R.id.btnPasserParcel);

    }
}